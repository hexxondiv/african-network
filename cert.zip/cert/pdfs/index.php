<?php
// Define the base URL
//$base_url = 'http://localhost/anrd/cert/';
$base_url = 'https://neadafrica.com/cert/';
// Redirect to base URL
header("Location: $base_url");
exit();
?>
