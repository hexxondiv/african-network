<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEAD Certificate Validation Portal</title>
   <link rel="icon" type="image/x-icon" href="logo.png"> <!-- Favicon link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .center-container {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        .spinner-container {
            display: none;
            justify-content: center;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <?php
    // Define the base URL
    //$base_url = 'http://localhost/anrd/cert/';
    $base_url = 'https://neadafrica.com/cert/';
    $home_url = 'https://neadafrica.com/';
    ?>
    
    <div class="center-container col-md-12 card">
        <div class="text-center">
            <!-- Logo Header -->
            <a href="<?php echo $home_url?>"><img src="logo.png" alt="Logo" class="mb-4" style="max-width: 150px;"></a>
           
            <h4 class="text-muted">Network for Educational Advancement and Development</h4>
            <h3>Certificate Verification Portal</h3>
            <form method="GET" action="">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="ref" placeholder="Enter Reference Number" required>
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </div>
            </form>

            <div id="spinner" class="spinner-container">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>

            <?php
            if (isset($_GET['ref'])) {
                $ref = htmlspecialchars($_GET['ref']);
                $file_path = "pdfs/{$ref}.pdf";

                if (file_exists($file_path)) {
                    echo "<script>
                            var baseUrl = '{$base_url}';
                            document.getElementById('spinner').style.display = 'flex';
                            setTimeout(function() {
                                document.getElementById('spinner').style.display = 'none';
                                var newWindow = window.open('$file_path', '_blank');
                                if (!newWindow || newWindow.closed || typeof newWindow.closed == 'undefined') {
                                    alert('Pop-up blocked! Please allow pop-ups for this site.');
                                }
                                else{window.location.href = baseUrl;} // Redirect to base URL
                            }, 4000);
                          </script>";
                    echo "<div class='alert alert-success'>PDF found! The file will open in a new tab shortly.</div>";
                    echo "<div class='alert alert-default'>If not opened automatically, click <a href='$file_path' target='_blank'>Open PDF</a></div>";
                } else {
                    echo "<div class='alert alert-danger'>No PDF found for the ref number: $ref</div>";
                }
            }
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

